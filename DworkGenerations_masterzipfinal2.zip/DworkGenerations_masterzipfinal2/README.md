# Which String Vibrations Become Which Generations on the Dwork Quintic

Deep Bhattacharjee and Ushashi Bhattacharya

- `DworkGenerations_final2.pdf`: the paper (21 pages).
- `DworkGenerations_final2-tex.zip`: its LaTeX source with the figures as PNG. It compiles with
  plain `pdflatex` (REVTeX 4.2, TeX Live 2026), with no BibTeX pass and no shell escape.
- `DworkGenerations-v1.1.0-arxiv.tar.gz`: the arXiv package, with the checks, the record of the
  Anaxia engine and the Lean file in `anc/`.
- `strings-v1.1.0/`: the repository creelie/strings at release 1.1.0: the paper, the 121
  independent checks in C, C++, Python, Julia, Macaulay2 and shell (`code/run_checks.sh`), the
  14 Lean 4 theorems (`lean/Strings.lean`) and the engine record (`code/bllm/`).

The archive is on Zenodo: release 1.1.0 under doi:10.5281/zenodo.23484427, all versions under
doi:10.5281/zenodo.23480310. The Anaxia engine used for the constructions is creelie/eBLLM,
release 3.1.0, doi:10.5281/zenodo.23484160.
